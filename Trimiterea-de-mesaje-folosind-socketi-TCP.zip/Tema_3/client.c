#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <unistd.h>
#include <unistd.h>


#define BUFLEN 256

/*functie care afisaza eroarea dorita*/
void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    int sockfd, n,nume,port, comanda;
    struct sockaddr_in serv_addr;
    struct hostent *server;
		
		fd_set read_fds, tmp_fds;	
		int fdmax;	
		 
    char buffer[BUFLEN]; //mesajul citit de la tastatura
    char client_name[BUFLEN]; //numele clientului
    char port_client[BUFLEN]; //portul clientului
    char comanda_client[BUFLEN]; //comanda pe care doresc sa o dau clientului
    char vector_mesaje[100];
    int u;
   
   


    /*clientul are 4 parametri*/
    if (argc < 5) {
       fprintf(stderr,"Usage %s client_name client_port server_ip server_port\n", argv[0]);
       exit(0);
    }  

    FD_ZERO(&read_fds);
    FD_ZERO(&tmp_fds);
    
    sockfd = socket(AF_INET, SOCK_STREAM, 0);//socket-ul

    if (sockfd < 0) 
	{
        error("ERROR opening socket");
	}
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[4])); //parametrul 4 reprezinta portul serverului
    inet_aton(argv[3], &serv_addr.sin_addr); //parametrul 3 reprezinta adresa serverului
    strcpy(client_name, argv[1]); // parametrul 1 reprezinta numele clientului
    strcpy(port_client, argv[2]); //parametrul 2 reprezinta portul clientului 
   
    
    FD_SET(sockfd, &read_fds);
    FD_SET(0, &read_fds);
    fdmax = sockfd;
       
    if (connect(sockfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting"); 
   
  
    while(1){
 
     
    tmp_fds = read_fds;

   

    if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
			error("ERROR in select");


    if (FD_ISSET(0, &tmp_fds))   {
	
 

	//printf("Introduceti un mesaj sau o comanda pentru client. In cazul in care comanda nu este una valida acesta va fii un mesaj trimis serverului.\n");
  	//citesc de la tastatura
	
    	memset(buffer, 0 , BUFLEN);
    	fgets(buffer, BUFLEN-1, stdin);
	
	//trimitere mesaj catre server
    	n = send(sockfd,buffer,strlen(buffer), 0);

    	if (n < 0) 
		{
        	 error("ERROR writing message to socket");
		}

	//trimitere numele clientului catre server
	nume = send(sockfd, client_name, strlen(client_name),0);
	
	if(nume < 0)
		{
			error("ERROR writing name to socket");
		}

	//trimitere port client catre server
	port = send(sockfd, port_client, strlen(port_client), 0);

	if(port < 0)
		{
			error("ERROR writing port to socket");
		}

	//Un client poate sa dea o comanda numai dupa ce trimite un prim mesaj catre server pentru ai memora datele 
	printf("Doriti sa introduceti o comanda pentru acest client?\n"); //Daca doriti sa dati o comanda clientului introduceti "da", 
									//in caz contrar introduceti "nu"
	char ma_gandesc[BUFLEN];//variabila in care retin alegerea facuta
	scanf("%s", ma_gandesc); //introduc de la tastatura alegerea
	if(strcmp(ma_gandesc, "da") == 0){ //daca raspunsul e "da" atunci dau clientului o serie de comenzi
	
	printf("Puteti sa introduceti o comanda:\n"); // introduceti comanda pe care o doriti pentru client
	scanf("%s", comanda_client); //introduc de la tastatura comanda dorita
	int u;
   	if(strcmp(comanda_client, "listclients") == 0){ //daca trimit comanda "listclients" atuncti serverul trebyie sa-mi trimita lista cu totii clientii 								conectati
	

		u = send(sockfd, comanda_client, strlen(comanda_client), 0); //trimit comanda catre server. La primirea acestui mesaj (comanda), serverul imi va trimite o lista cu totii clientii conectati pana in momentul respectiv
		if(u < 0)
		{
			error("ERROR writing message to socket");
		}
		

 	}
		
	if(strcmp(comanda_client, "quit") == 0 ){ //comanda quit inchide clientul respectiv
		break;
	}
	//Pentru comanda "infoclient <nume>" introduc mai intai comanda "infoclient", dupa care trebuie sa introduc numele clientului despre care vreau informatii
	if(strcmp(comanda_client, "infoclient") >= 0){
		printf("Introduceti numele clientului despre care doriti sa primiti informatii: \n");
		char info_client[BUFLEN];
		scanf("%s", info_client);//introduc de la tastatura numele clientului ale carui informatii le doresc
		int date;
		date = send(sockfd, info_client, strlen(info_client), 0); // trimit serverului numele clientului, la primirea acestuia el imi va trimite datele clientului respectiv
		if(date < 0)
		{
			error("ERROR writing message to socket");
		}
	}
	//La fel ca la comanda anterioara introduc mai intai comanda "messaje" dupa care numele clientului, iar apoi mesajul pe care doresc sa-il trimit
	if(strcmp(comanda_client, "message") >= 0){
		printf("Introduceti numele clientului catre care doriti sa trimiteti mesajul:\n");
		char client_dorit[BUFLEN];
		scanf("%s", client_dorit);
		printf("Introduceti mesajul pe care doriti sa il trimiteti clientului de mai sus:\n");
		char mesaj_dorit[BUFLEN];
		scanf("%s", mesaj_dorit);
		int trimitere = 0;
		trimitere = send(sockfd, client_dorit, strlen(client_dorit), 0);//trimit serverului numele clientului
		if(trimitere < 0)
		{
			error("ERROR writing message to socket");
		}
	        trimitere = send(sockfd, mesaj_dorit, strlen(mesaj_dorit), 0);//trimit serverului masajul
		if(trimitere < 0)
		{
			error("ERROR writing message to socket");
		}
	}
	//Daca coamanda este "broadcast" atunci trimit un mesaj catre totii clientii
	if(strcmp(comanda_client, "broadcast") >= 0){
		printf("Trimit un mesajul catre toti clientii.\n");
		printf("Introduceti mesajul pe care doriti sa il trimiteti la toti clientii\n");
		char mesaj_de_trimis[BUFLEN];
		int tri = 0;
		tri = send(sockfd, mesaj_de_trimis, strlen(mesaj_de_trimis), 0);
		if(tri < 0)
		{
			error("ERROR writing message to socket");
		}
		tri = send(sockfd, comanda_client, strlen(comanda_client), 0);
		
	}

	if(strcmp(comanda_client, "history") >= 0){
		printf("Acestea sunt mesajele pe care eu le-am primit:\n");

	}
   }
	
	}

	

		if (FD_ISSET(sockfd, &tmp_fds)){
			memset(buffer, 0, BUFLEN);
				
					if ((n = recv(sockfd, buffer, sizeof(buffer), 0)) <= 0) {
						error("ERROR in recv");
					}
					else  
					     {	
						//printf("Mesajul trimis este: %s \n", buffer);
						printf("%s \n", buffer);
					     } 	
					

			//memset(client_name, 0, BUFLEN);
					if((nume = recv(sockfd, client_name, sizeof(client_name), 0)) <= 0){
						error("ERROR  in recv");
					}
					else
					    {	
						//printf("Numele clientului este :%s \n", client_name);
					     } 	
			//memset(port_client, 0, BUFLEN);
					if((port = recv(sockfd, port_client, sizeof(port_client), 0)) <= 0){
						error("ERROR  in recv");
					}
					else
					    {	
						//printf("Portul clientului este :%s \n", port_client);
					     } 
					//Serverul anunta un client ca trebuie sa inchida conexiunea
					if(strcmp(buffer, "inchidere") == 0)
						{
							int socked_end = sockfd + 1;
							close(socked_end);
							printf("Am inchis conexiunea!!!!!!!!!\n");
						}
					//Serverul anunta clientii ca el se va inchide, acest lucru duce la inchiderea clientiilor
					if(strcmp(buffer, "Server inchis") == 0)
					{
						break;
					}
					//Clientul asteapta lista cu clientii
					if(strcmp(buffer, "Iti trimit") == 0)
					{
						printf("Astept. Multumesc!\n");
						
						
					}
			}
	
}
	
   
    return 0;
}


