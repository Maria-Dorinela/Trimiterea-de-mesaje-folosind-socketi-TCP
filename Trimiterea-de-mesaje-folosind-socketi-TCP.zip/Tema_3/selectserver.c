#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_CLIENTS	20
#define BUFLEN 256
#define BUFLEN_S 25600

void error(char *msg)
{
    perror(msg);
    exit(1);
}

typedef char * string;

//structura in care pastrez informatiile despre clienti
typedef struct 
{
	char *adresa_ip;
	int port;
	char *client_nume;
	char *client_port;
	char *mesaj;
	int socket_client;
	
}Informatii_clienti;


int main(int argc, char *argv[])
{
     int sockfd, newsockfd, portno, clilen,nume,port;
     char buffer[BUFLEN];//mesajul de la client
     char client_name[BUFLEN];//numele clientului
     char port_client[BUFLEN]; //portul clientului
     struct sockaddr_in serv_addr, cli_addr;
     int n, i, j;
     int p = 0,pp = 0;
     Informatii_clienti info[100];
     int nr_clienti = 0;
     char comanda_server[BUFLEN]; //comanda pe care dorim sa o dam serverului
     char elimina[BUFLEN]; //numele clientului pe care dorim sa il eliminam din sistem

     fd_set read_fds;	//multimea de citire folosita in select()
     fd_set tmp_fds;	//multime folosita temporar 
     int fdmax;		//valoare maxima file descriptor din multimea read_fds
    
     char mesaje_client[100]; //mesajele clientiilor primite de la alti clienti

    

     if (argc < 2) {
         fprintf(stderr,"Usage : %s port\n", argv[0]);
         exit(1);
     }

     //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
     FD_ZERO(&read_fds);
     FD_ZERO(&tmp_fds);
     
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening socket");
     
     portno = atoi(argv[1]);

     memset((char *) &serv_addr, 0, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;	// foloseste adresa IP a masinii
     serv_addr.sin_port = htons(portno);
     
     if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr)) < 0) 
              error("ERROR on binding");
     
     listen(sockfd, MAX_CLIENTS);

     //adaugam noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
     FD_SET(sockfd, &read_fds);
     fdmax = sockfd;

	char stare[BUFLEN];
	
	while(1){


		tmp_fds = read_fds; 
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
			error("ERROR in select");
	
		for(i = 0; i <= fdmax; i++) {
	
			if (FD_ISSET(i, &tmp_fds)) {
			
				if (i == sockfd) {
					
					// a venit ceva pe socketul inactiv(cel cu listen) = o noua conexiune
					// actiunea serverului: accept()
					clilen = sizeof(cli_addr);
					if ((newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen)) == -1) {
						error("ERROR in accept");
					} 
					else {
						//adaug noul socket intors de accept() la multimea descriptorilor de citire
						FD_SET(newsockfd, &read_fds);
						if (newsockfd > fdmax) { 
							fdmax = newsockfd;
						}
					}
					printf("Noua conexiune de la %s, port %d, socket_client %d\n ", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), newsockfd);
					printf("Avem %d clienti\n", fdmax - 3);
	
				}
					
				else {
					// am primit date pe unul din socketii cu care vorbesc cu clientii
					//actiunea serverului: recv()
					memset(buffer, 0, BUFLEN);
					memset(client_name, 0, BUFLEN);
					memset(port_client, 0, BUFLEN);

					
					if (((n = recv(i, buffer, sizeof(buffer), 0)) <= 0 ) || ((nume = recv(i, client_name, sizeof(client_name), 0)) <= 0 ) || (						(port = recv(i, port_client, sizeof(port_client), 0)) <= 0 )) {
						if (n == 0 || nume == 0 || port == 0) {
							//conexiunea s-a inchis
							printf("Am iesit\n");
							printf("selectserver: socket %d hung up\n", i);
						} else {
							error("ERROR in recv");
						}
						close(i); 
						FD_CLR(i, &read_fds); // scoatem din multimea de citire socketul pe care 
					} 
					
					else { //recv intoarce >0

					/*if(strcmp(buffer, "listclients") == 0){
						printf("Am primit. O sa trimit lista cu totii clientii\n");
						}
					else
						printf("Nu am primit");*/
					
					 
					//introducere date in structura
					info[pp].adresa_ip = inet_ntoa(cli_addr.sin_addr);
					info[pp].port = ntohs(cli_addr.sin_port);
					info[pp].client_nume = client_name;
					info[pp].client_port = port_client;
					info[pp].socket_client = i;
					info[pp].mesaj = buffer;
					
				
					printf ("\nAm primit de la clientul de pe socketul %d,cu adresa %s, mesajul: %sNumele clientului este: %s\nPortul clientului este:  %s\nSocketul este: %d \n", info[pp].socket_client, info[pp].adresa_ip , info[pp].mesaj, info[pp].client_nume, info[pp].client_port, info[pp].socket_client);
					//Daca de la client am primit "listclients" atunci trimit clientului lista cu toti clientii conectati pana in momentul respectiv
					if (strcmp(buffer, "listclients") == 0){
						printf("O sa trimit lista cu totii clientii\n");
						char confirmare[BUFLEN];
						int rezultat = 0;
						strcpy(confirmare, "Iti trimit");
						rezultat = send(info[pp].socket_client, confirmare, sizeof(confirmare),0);
						if(rezultat < 0)
						{
							error("ERROR writing port to socket");
						}
						int t = 0;
						for(t = 0; t < nr_clienti; t++){
							rezultat = send(info[pp].socket_client,info[t].client_nume,sizeof(info[t].client_nume),0);
							if(rezultat < 0)
							{
								error("ERROR writing port to socket");
							}
							else{
								
							}
						}
						
					}
					
					
					else{
						printf("Continuare\n");
					}
					int e;
					//Parcurg toti clientii. Daca mesajul pe care il primesc acum este identic cu un nume din structura atunci trimit informatiile despre clientul respectiv (al carui nume este mesajul primit)
					for(e = 0; e < nr_clienti; e++){
						if(strcmp(buffer, info[e].client_nume) == 0){
							printf("O sa-ti trimit lista cu informatiile despre clientul dorit\n");
							int w = 0;
							int ww = 0;
							w = send(info[pp].socket_client, info[e].client_nume, sizeof(info[e].client_nume), 0);
							if(w < 0)
							{
								error("ERROR writing port to socket");
							}
							ww = send(info[pp].socket_client, &info[e].port, sizeof(info[e].client_nume), 0);
							if(ww < 0)
							{
								error("ERROR writing port to socket");
							}
						}
						else{
							printf("Clientul despre care doriti sa aflati informatii nu este conectat inca.\n");
						}
					}
					
					//Daca am primit orice mesaj , ma uit cu un pas in urma si vad daca mesajul pe care l-am primit la pasul i-1 este un nume de client din structura, atunci trebuie sa trimit mesajul primit la pasul i  clientului de la pasul i-1
					for(e = 1; e < nr_clienti; e++){
						if(strcmp(buffer, info[e-1].client_nume) == 0){
							printf("O sa trimit mesajul catre clientul dorit.\n");
							int j, k; 
							char* word; 
							char word1[BUFLEN];
					
							memset(word1, 0 , BUFLEN);	
							strcpy(word1,buffer);
							word = strtok(word1," ");
							j = atoi(word);	
							char *tmp = strchr(buffer, ' ');
							if(tmp != NULL){	
								if (FD_ISSET(j, &read_fds) && (j!=i) && (j!=sockfd)){ 
									if ( send(j, tmp+1, n, 0)< 0)
										printf("Eroare trimitere mesaj catre client!!!");

				       				}

							}
						
						}
						else{
							printf("Clientul caruia doriti sa-i trimiteti un mesaj nu este conectat inca.\n");
						}
					}

					for(e = 1; e < nr_clienti; e++){
						if(strcmp(buffer, "broadcast") == 0){
							printf("O sa trimit mesajul catre toti clientii.\n");
							int jj, kk; 
							char* word2; 
							char word3[BUFLEN];
					
							memset(word3, 0 , BUFLEN);	
							strcpy(word3,buffer);
							word2 = strtok(word3," ");
							j = atoi(word2);	
							char *tmp1 = strchr(buffer, ' ');
							if(tmp1 != NULL){	
								if (FD_ISSET(jj, &read_fds) && (jj!=i) && (jj!=sockfd)){ 
									
									if ( send(jj, tmp1+1, n, 0)< 0)
										printf("Eroare trimitere mesaj catre client!!!");

				       				}

							}
						
						}
						else{
							
						}
					}
					
					pp++;
					nr_clienti ++;
					}

      			 } 

     		} 
   	} 


printf("\nIntroduceti o comanda valida pe care doriti sa o dati serverului numai dupa ce fiecare client conectat trimite un mesaj catre server pentru a putea retine datele despre clientul respectiv: \n");
int m = 0;
scanf("%s", comanda_server);

	//Daca comanda este "status" atunci afisez lista tuturor clientilor conectati
	if(strcmp(comanda_server, "status") == 0){
		printf("Lista clientiilor conectati este: \n");
		for(m = 0; m < nr_clienti; m++){
			printf("Clientul: %d\n", m);
			printf("adresa: %s, port: %d ,nume client: %s, port client: %s, socket: %d\n", info[m].adresa_ip, info[m].port,  info[m].client_port,info[m].client_nume, info[m].socket_client);
		}

}
	//Daca comanda este "kick" atunci inhid un client. Numele clientului il citesc de la tastatura.
	
	if(strcmp(comanda_server, "kick") == 0){
		int t = 0;
		printf("Introduceti numele clientului pe care doriti sa il eliminati din sistem:\n");
		scanf("%s", elimina);
		for(t = 0; t <= nr_clienti; t++){
			if(strcmp(elimina, info[t].client_nume) >= 0){
				int s = info[t].socket_client;
				char mesaj_client[BUFLEN];
				int r;
				strcpy(mesaj_client, "inchidere"); //Serverul anunta mai intai clientul ca acesta va fii inchis prin trimiterea mesajului "inchidere".
				r = send(s, mesaj_client, strlen(mesaj_client), 0);
					if(r < 0)
						{
							error("ERROR writing port to socket");
						}
			break;

			}
			else{
				printf("Nu exista nici un client cu acest nume\n");
			}

		}
	}
	//Daca comanda e "quit" serverul se inchide si anunta clientii pentru a se inchide si ei
	if(strcmp(comanda_server, "quit") == 0){
		printf("Serverul s-a inchis!!!!. La fel si clientii: \n");
		int c = 0;
		for(c = 0; c < nr_clienti; c++){
			char mesaj_client[BUFLEN];
				int r;
				strcpy(mesaj_client, "Server inchis");
				r = send(info[c].socket_client, mesaj_client, strlen(mesaj_client), 0);
					if(r < 0)
						{
							error("ERROR writing port to socket");
						}


		}
	break;
	}
else{
 printf("COMANDA INVALIDA!!! La aceata comanda serverul nu stie ce sa faca. Continuati!!\n\n");
 }
} 
  close(sockfd); 
 

     return 0; 
}


