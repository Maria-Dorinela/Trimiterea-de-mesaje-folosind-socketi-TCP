SIRBU MARIA-DORINELA
325 CB
TEMA 3 PC

	In rezolvarea acestei tema am avut ca sursa de inspiratie laboratorul 5.
	Clientul cand trimite mesajul trimite si datele despre el: nume, port.
	Pentru a putea da o comanda unui client am presupus ca mai intai acel client trebuie
sa trimita un mesaj, astfel pot sa retin datele despre el.
	Dupa ce a trimis catre server primul mesaj clientul este intrebat daca doreste
sa introduca o comanda.
	In functie de comanda pe care introduce de la tastatura se intra in diferite if-uri
	Pentru comenziile cum ar fii: "infoclient", "message"..., introduc mai intai comanda
"infoclient" de exemplu dupa care imi cere numele clientului despre care doresc informatii.
Practic comenziile de acest tip sunt formate din bucatii, pe pasi.
	

	In selectserver.c pastrez intr-o structura "Informatii_clienti" datele clientilor: nume, port, adresa ip, ... .
	Dupa ce un client se conecteaza la el , server-ul trebuie sa introduca una din cele trei comenzii.
In cazul in care nu a introdus niciuna din cele trei comenzii, atunci apare mesajul "COMANDA INVALIDA", si continua.

	
	In cod am comentat ce face fiecare instructiune, pentru mine acest lucru este mai usor de urmarit.

	Nu am implementat trimiterea de fisiere.